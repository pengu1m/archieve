import Express from "express"

import { fake } from "./router/fake"
import { survey } from "./router/stat"

const app = Express()

app.use("/p", fake) // p is shortword of 'persudo'
app.use("/stat", survey)

const PORT = 3000
app.listen(PORT, () => console.log(`🚀 Server listening on PORT:${PORT}`))
