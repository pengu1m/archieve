import { Router } from "express"
import { p } from "../util/path"

export const fake = Router()

let boomed = false

fake.get("/", (req, res) => {
  if (boomed) {
    res.sendFile(p("pages/real.html"))
    return
  }

  res.sendFile(p("pages/fake.html"))
})

fake.get("/check", (req, res) => {
  res.send({
    boomed: boomed
  })
})

const SECRET_KEY = "12312312313123131313"
fake.get(`/boom_on_${SECRET_KEY}`, (req, res) => {
  boomed = true
  res.send("💣 The boom was on!")
})
