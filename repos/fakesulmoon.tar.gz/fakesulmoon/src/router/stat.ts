import { Router } from "express"
import { p } from "../util/path"

export const survey = Router()

survey.get("/", (req, res) => {
    res.sendFile(p("pages/thank.html"))
  //res.sendStatus(404)
})
