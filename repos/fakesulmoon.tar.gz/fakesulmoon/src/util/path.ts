import Path from "path"

export const p = (path: string) => {
  return Path.join(process.cwd(), "src", path)
}
