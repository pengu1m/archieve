import { Router, Route } from "@solidjs/router"

import Home from "@pages/home"
import Profile from "@pages/profile"
import Projects from "@pages/projects"
import Detail from "@pages/detail"

function App() {
  //const [count, setCount] = createSignal(0)

  return (
    <Router>
      <Route path="/" component={Home} />
      <Route path="/profile" component={Profile} />
      <Route path="/projects" component={Projects} />
      <Route path="/projects/:name" component={Detail} />
    </Router>
  )
}

export default App
