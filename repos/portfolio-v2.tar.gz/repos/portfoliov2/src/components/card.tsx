import { A } from "@solidjs/router"

interface CardProps {
    href: string
    date: string
    view: number
    title: string
    description: string
}

function Card({href, date, view, title, description}: CardProps) {
    return (
        <A href={href} class="card">
            <div class="card__meta">
                <span class="card__date">{date}</span>
                <span class="card__view">{view} views</span>
            </div>

            <h2 class="card__title">{title}</h2>

            <p class="card__description">{description}</p>
        </A>
    )
}

export default Card