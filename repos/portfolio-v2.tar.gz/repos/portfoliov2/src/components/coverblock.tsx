interface CoverblockProps {
    title: string
    description: string
}

function Coverblock({title, description}: CoverblockProps) {
    return (
        <div class="coverblock">
            <h1 class="coverblock__title">{title}</h1>

            <p class="coverblock__description">{description}</p>
        </div>
    )
}

export default Coverblock