const GetCurrentDate = () => {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
        "July", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    
    const d = new Date();
    const month = monthNames[d.getMonth()]

    return `${month} ${d.getDate()}, ${d.getFullYear()}`
}

function Footer() {
    return (
    <footer class="footer">
        {/* this hr is optional, but recommeneded */}
        <hr class="hr"/>

        <div class="footer__info">
            <span class="footer__license">GPL 3.0</span>
            <span class="footer__lastmod">{GetCurrentDate()}</span>
        </div>
    </footer>
    )
}

export default Footer