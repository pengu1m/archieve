import { JSXElement } from "solid-js"

interface GridProps {
    hor: number
    gap: number
    centered: boolean
    children: JSXElement
}

function Grid({hor, gap, centered, children}: GridProps) {
    if (hor < 0 || 5 < hor) {
        throw new Error("'hor' or <Grid /> is natrual number between 1 ~ 5")
    }

    if (gap < 0 || 5 < gap) {
        throw new Error("'gap' or <Grid /> is natrual number between 1 ~ 5")
    }

    if (centered) {
        return <div class={`grid-${hor}--gap-${gap}--center`}>{children}</div>    
    }

    return <div class={`grid-${hor}--gap-${gap}`}>{children}</div>
}

export default Grid;