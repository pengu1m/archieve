function Hr() {
    return <hr class="hr" />
}

export default Hr