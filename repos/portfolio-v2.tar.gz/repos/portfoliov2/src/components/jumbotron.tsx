import { A } from "@solidjs/router"

interface JumbotronProps {
    links: Array<{
        name: string
        href: string
    }>
    title: string
    description: string
}

function Jumbotron({links, title, description}: JumbotronProps) {
    return (
        <div class="jumbotron">
            <nav class="jumbotron__nav">
                {links.map((item) => <A href={item.href} class="jumbotron__link">{item.name}</A>)}
            </nav>

            <header class="jumbotron__logo">{title}</header>

            <p class="jumbotron__description">{description}</p>
        </div>
    )
}

export default Jumbotron