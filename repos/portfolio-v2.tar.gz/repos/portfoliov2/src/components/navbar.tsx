import { A, useNavigate } from "@solidjs/router"

interface NavbarProps {
    links: Array<{
        name: string
        href: string
    }>
}

function Navbar({links}: NavbarProps) {
    const navigate = useNavigate()
    
    const goto_home = () => navigate("/")
    return (
        <header class="navbar">
            <button class="navbar__back" onClick={goto_home}>←</button>

            <nav class="navbar__nav">
                { links.map((item) => <A href={item.href} class="navbar__link">{item.name}</A>) }
            </nav>
        </header>
    )
}

export default Navbar