import { DevBlog, Specs, Personal } from "@model/data/blog.json"

interface Blog {
    name: string,
    description: string,
    link: string,
    platform: string
}

export function GetAllBlogs(): Array<Blog> {
    return [DevBlog, Specs, Personal]
}

export function GetDevBlog(): Blog {
    return DevBlog
}

export function GetSpecBlog(): Blog {
    return Specs
}

export function GetPersonalBlog(): Blog {
    return Personal
}
