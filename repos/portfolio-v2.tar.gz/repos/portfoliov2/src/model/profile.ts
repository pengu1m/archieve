import profile from "@model/data/profile.json"

interface TechEntry {
    topic: string,
    list: Array<string>
}

interface ContactEntry {
    name: string,
    link: string
}

interface Contacts {
    github: ContactEntry,
    email: ContactEntry,
    discord: ContactEntry
}

export function GetTechstack(): Array<TechEntry> {
    return profile.techstack
}

export function GetContacts(): Contacts {
    return profile.contact
}
