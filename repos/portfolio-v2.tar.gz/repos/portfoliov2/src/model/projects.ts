import portfoliov2 from "@model/data/projects/portfoliov2.json"

interface Project {
    name: string
    description: string
    date: string
    view: number
    techstack: Array<string>
    github: string
    url: string
    deployment: string
    license: string
}

const majors: Array<Project> = [portfoliov2]
const minors: Array<Project> = []

export function GetAllProjects(): Array<Project> {
    return majors.concat(minors)
}

export function GetAllMajorProjects(): Array<Project> {
    return majors
}

export function GetAllMinorProjects(): Array<Project> {
    return minors
}

export function GetProjectByName(name: string): Project {
    const all_proj = GetAllProjects()

    const found_proj = all_proj.filter((item) => item.name === name)

    if (found_proj.length === 0) {
        return {
            name: "Not found",
            description: `Project '${name}' doesn't exist!`,
            date: "June 23, 2007",
            view: 1000,
            techstack: [],
            github: "#",
            url: "#",
            deployment: "",
            license: "WTFPL"
        }
    }

    if (found_proj.length > 1) {
        return {
            name: "Error at finding project",
            description: `There was an error at finding project '${name}'`,
            date: "June 23, 2007",
            view: 1000,
            techstack: [],
            github: "#",
            url: "#",
            deployment: "",
            license: "WTFPL"
        }
    }
    
    return found_proj[0]
}