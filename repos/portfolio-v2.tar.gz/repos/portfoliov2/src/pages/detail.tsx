import Coverblock from "@components/coverblock"
import Footer from "@components/footer"
import Navbar from "@components/navbar"

import { GetDevBlog } from "@model/blog"
import { GetProjectByName } from "@model/projects"

import { useParams } from "@solidjs/router"

const navbar_links = [
    {
        name: "profile",
        href: "/profile"
    },
    {   
        name: GetDevBlog().name,
        href: GetDevBlog().link
    }
]

function Detail() {
    const param = useParams()
    
    const proj = GetProjectByName(param.name)
    
    return (
        <>
            <Navbar links={navbar_links}/>

            <Coverblock title={proj.name} description={proj.description} />

            <main class="responsive--auto">
                <h2>Techstack</h2>
                <ul>{proj.techstack.map((item) => <li>{item}</li>)}</ul>

                <h2>Links</h2>
                <ul>
                    <li><a href={proj.github}>Github</a></li>
                    <li><a href={proj.url}>Deployment URL ({proj.deployment})</a></li>
                </ul>

                <h2>License</h2>
                <p>GPL 3.0</p>

                <Footer />  
            </main>
        </>
    )
}

export default Detail