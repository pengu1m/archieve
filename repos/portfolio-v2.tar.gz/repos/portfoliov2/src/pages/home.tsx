import Jumbotron from "@components/jumbotron"

import { GetDevBlog } from "@model/blog"

const links = [
    {
        name: "Profile",
        href: "/profile"
    },
    {
        name: "Projects",
        href: "/projects"
    },
    {
        name: GetDevBlog().name,
        href: GetDevBlog().link
    }
]

function Home() {
    return <Jumbotron title="Pengu1m" description="웹과 게임에 관심이 있는 예비 개발자" links={links}/>
}

export default Home