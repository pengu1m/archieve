import Navbar from "@components/navbar"
import Coverblock from "@components/coverblock"
import Footer from "@components/footer"
import * as Icons from "@components/icons"

import { GetDevBlog, GetPersonalBlog, GetSpecBlog } from "@model/blog"
import { GetContacts, GetTechstack } from "@model/profile"
import { JSXElement } from "solid-js"
import Grid from "@components/grid"

const navbar_links = [
    {
        name: "projects",
        href: "/projects"
    },
    {   
        name: GetDevBlog().name,
        href: GetDevBlog().link
    }
]

const contacts = GetContacts()
const dev_blog = GetDevBlog()
const spec_blog = GetSpecBlog()
const personal_blog = GetPersonalBlog()

interface IconTextProps {
    text: string
    link: string
    children: JSXElement
}

function IconText({text, link, children}: IconTextProps) {
    return (
        <div>
            {children}
            <h3>
                <a href={link} class="anchor">{text}</a>
            </h3>
        </div>
    )
}

function Profile() {
    return (
        <>
            <Navbar links={navbar_links}/>

            <Coverblock title="Profile of Pengu1m" description="웹과 게임에 관심이 있는 예비 개발자" />

            <main class="responsive--auto">
                <h2>My tech stack</h2>
                <ul>
                    {
                        GetTechstack().map((item) => (
                            <li>
                                <ul>
                                    <h3>{item.topic}</h3>

                                    {item.list.map((item) => <li>{item}</li>)}
                                </ul>
                            </li>
                        ))
                    }
                </ul>

                <h2 class="text-center">Blog</h2>
                <Grid hor={3} gap={3} centered={true}>
                    <IconText text="Dev blog" link={dev_blog.link}>
                        <Icons.Terminal size={80} />
                    </IconText>
                    <IconText text="Specs" link={spec_blog.link}>
                        <Icons.PDF size={80} />
                    </IconText>
                    <IconText text="Personal" link={personal_blog.link}>
                        <Icons.Coffee size={80} />
                    </IconText>
                </Grid>

                <h2 class="text-center">Contacts</h2>
                <Grid hor={3} gap={3} centered={true}>
                    <IconText text={contacts.github.name} link={contacts.github.link}>
                        <Icons.Github size={80} />
                    </IconText>
                    <IconText text={contacts.discord.name} link={contacts.discord.link}>
                        <Icons.Discrod size={80} />
                    </IconText>
                    <IconText text="Gmail" link={contacts.email.link}>
                        <Icons.Email size={80} />
                    </IconText>
                </Grid>

                <Footer />
            </main>
        </>
    )
}

export default Profile