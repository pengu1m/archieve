import Navbar from "@components/navbar"
import Hr from "@components/hr"
import Grid from "@components/grid"
import Card from "@components/card"

import { GetAllMajorProjects, GetAllMinorProjects } from "@model/projects"
import { GetDevBlog } from "@model/blog"

const navbar_links = [
    {
        name: "profile",
        href: "/profile"
    },
    {   
        name: GetDevBlog().name,
        href: GetDevBlog().link
    }
]

function Home() {
    return (
        <>
            <Navbar links={navbar_links} />

            <main class="responsive--mobile">
                <h1>지금까지 만들어 왔던 프로젝트들</h1>

                <Hr />

                {/* Pinned projects */}
                <Grid hor={1} gap={2} centered={false}>
                    {
                        GetAllMajorProjects().map((item) => (
                            <Card 
                                title={item.name}
                                description={item.description}
                                date={item.date}
                                view={item.view}
                                href={`/projects/${item.name}`}
                            />
                        ))
                    }
                </Grid>

                {/* Unpinned projects */}
                <Grid hor={4} gap={2} centered={false}>
                    {
                        GetAllMinorProjects().map((item) => (
                            <Card 
                                title={item.name}
                                description={item.description}
                                date={item.date}
                                view={item.view}
                                href={`/projects/${item.name}`}
                            />
                        ))
                    }
                </Grid>
            </main>
        </>
    )
}

export default Home