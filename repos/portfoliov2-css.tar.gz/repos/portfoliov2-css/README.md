# portfoliov2-css

A styleset for portfoliov2

## Getting started

First, you should install `dart sass`

```bash
npm install -g sass
```

You can compile `.scss` to `.css` with following command.

```bash
git clone https://github.com/pengu1m/starter-blog-css.git
sass main.scss ./build/min.css
# Compile main.scss
# It imports all files under 'components'
```

You can also use `--watch` or `--style=compressed` for dev and production.

## Style Concepts

- Motivated by the design of [Chronark][chronark]
- No "primary color"
- 60% : 30% : 10% rule

## Components

- Navbar
- Footer
- Jumbotron
- Coverblock
- Card
- Responsive
- Hr
- Grid

## Usage (BEM)

### Navbar

```html
<header class="navbar">
    <button class="navbar__back">←</button>

    <nav class="navbar__nav">
        <a href="#" class="navbar__link">Link 01</a>
        <a href="#" class="navbar__link">Link 02</a>
        <a href="#" class="navbar__link">Link 03</a>
    </nav>
</header>

<!-- Warnings -->
<!-- Navbar doesnt contain h1 tag-->
```

### Footer

```html
<footer class="footer">
    <!-- this hr is optional, but recommeneded -->
    <hr class="hr"/>

    <div class="footer__info">
        <span class="footer__license">License name</span>
        <span class="footer__lastmod">Last modified date</span>
    </div>
</footer>
```

### Jumbotron

```html
<div class="jumbotron">
    <nav class="jumbotron__nav">
        <a href="#" class="jumbotron__link">Link 01</a>
        <a href="#" class="jumbotron__link">Link 02</a>
        <a href="#" class="jumbotron__link">Link 03</a>
    </nav>

    <header class="jumbotron__logo">Title</header>

    <p class="jumbotron__description">Short description</p>
</div>

<!-- Jumbotron will full-fill yout html page -->
<!-- If you use Jumbotron, use 'only' jumbotron under body tag -->
```

### Coverblock

```html
<div class="coverblock">
    <h1 class="coverblock__title">Title</h1>

    <p class="coverblock__description">Description but it can be long!</p>
</div>
```

### Card

```html
<a href="https://www.google.com" class="card">
    <div class="card__meta">
        <span class="card__date">Jul 1, 2023</span>
        <span class="card__view">1.0K</span>
    </div>

    <h2 class="card__title">Title</h2>

    <p class="card__description">Description and it can be long, too!</p>
</a>

<!-- Tips: whole card is anchor tag and you can use 'href' -->
<!-- But you dont have to -->
```

### Responsive

```html
<main class="responsive--auto">
    <!-- Automatically resize on desktop and mobile -->
    <!-- Desktop: 60vw -->
    <!-- Mobile: 95vw -->
</main>

<main class="responsive--desktop">
    <!-- Always 60vw -->
</main>

<main class="responsive--mobile">
    <!-- Always 95vw -->
</main>
```

### Hr

```html
<hr class="hr" />
```

### Grid

```html
<div class="grid-3__gap-3">
    ...
</div>

<div class="grid-3__gap-3--center">
    ...
    <!-- Same but align-items: center -->
</div>

<!-- Classname: grid-{horizental element count}__gap-{gap-size} -->
<!-- Availables: grid-1__gap-1 ~ grid-5__gap-5 -->
```

## Util classes

```html
<h1 class="text-center">...</h1>
<!-- Centered text -->

<div>
    <div class="m-auto">...</div>
    <!-- Margin: auto -->
</div>

<a class="anchor">This is anchor</a>

<div class="color-highlight">This is Highlighted color</div>
<div class="color-text">This is normal text color</div>
<div class="color-bg">This is normal background color</div>
```

[chronark]: https://chronark.com/
