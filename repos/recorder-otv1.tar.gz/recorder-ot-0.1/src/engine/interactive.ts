export enum EventType {
    WaitForTime,
    WaitForSpace,
}

export type InteractiveCallback = () => void

export type InteractiveEvent = {
    type: EventType.WaitForSpace,
    callback: InteractiveCallback
} | {
    type: EventType.WaitForTime,
    ms: number,
    callback: InteractiveCallback
}

const SPACE_KEY = " "

export class InteractiveManager {
    private list = new Array<InteractiveEvent>
    private can_input = true

    inputable(mode: boolean) {
        this.can_input = mode
    }

    push(event: InteractiveEvent) {
        this.list.push(event)
    }

    private index = 0
    run() {
        if (this.list.length === 0) throw new Error("Fail to use InteraciveManager (no event pushed)")

        this.index = 0
        this.inrun(this.list[this.index])
    }

    private timeouts = new Array<number>

    private inrun(event: InteractiveEvent) {
        if (event.type === EventType.WaitForTime) {
            const timer = setTimeout(() => {
                event.callback()

                this.timeouts.push(timer)
                this.timeouts.forEach(item => clearTimeout(item))
                
                this.index++
                if (this.index !== this.list.length) this.inrun(this.list[this.index])
            }, event.ms)
        }
        
        // event.type === EventType.WaitForSpace
        const listener = (e: KeyboardEvent) => {
            if (e.key !== SPACE_KEY) return

            if (this.can_input === false) return

            document.body.removeEventListener("keydown", listener)
            event.callback()

            this.index++
            if (this.index !== this.list.length) this.inrun(this.list[this.index])
        }

        document.body.addEventListener("keydown", listener)
    }
}
