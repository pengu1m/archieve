import React, { useEffect } from 'react'
import ReactDOM from 'react-dom/client'
import "./styles/global.css"

import {
  createBrowserRouter,
  RouterProvider
} from "react-router-dom"

import Fake from './pages/fake'
import Contents from './pages/contents'

import { EventType, InteractiveManager } from './engine/interactive'

const router = createBrowserRouter([
  {
    path: "/",
    element: <Fake />
  },
  {
    path: "/contents",
    element: <Contents />
  }
]);

const App = () => {
  useEffect(() => {
    const i = new InteractiveManager()

    i.push({
      type: EventType.WaitForTime,
      ms: 1000,
      callback: () => console.log("AFter 1000" + new Date())
    })
    
    i.push({
      type: EventType.WaitForTime,
      ms: 1000,
      callback: () => console.log("AFter 1000" + new Date())
    })
    
    i.push({
      type: EventType.WaitForSpace,
      callback: () => console.log("라스트 팡" + new Date())
    })
    
    i.run()
  }, [])
  return <RouterProvider router={router} />
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <App />
)
