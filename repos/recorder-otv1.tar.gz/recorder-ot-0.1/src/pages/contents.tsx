import "../styles/pages/contents.css"

const Contents = () => {
    return <div className="contents">
        <h1 className="contents__title">CONTENTS</h1>
        <div className="content__body">
            <ol className="contents__list">
                <li className="contents__item">간단한 소개</li>
                <li className="contents__item">배경</li>
                <li className="contents__item">목적</li>
                <li className="contents__item">운영구조</li>
                <li className="contents__item">앞으로의 계획</li>
                <li className="contents__item">오늘의 계획</li>
            </ol>
        </div>
    </div>
}

export default Contents
