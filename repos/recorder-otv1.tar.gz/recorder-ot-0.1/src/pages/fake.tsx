import "../styles/pages/fake.css"

const Fake = () => {
    return <div className="fake__centered">
        <h1 className="fake__title">OT</h1>
        <span className="fake__author">made it by 21001 강시온</span>
    </div>
}

export default Fake
