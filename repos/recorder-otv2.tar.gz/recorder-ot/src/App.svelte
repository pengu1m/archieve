<script lang="ts">
  import Router from "svelte-spa-router";
  
  import Profile from "./pages/profile.svelte"
  import Background from "./pages/background.svelte"

  const routes = {
    '/': Profile,
    '/background': Background
  }
</script>

<Router routes={routes} />
