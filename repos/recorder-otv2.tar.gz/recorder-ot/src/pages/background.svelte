<script lang="ts">
    import Notfoundwithposition from "../notfoundwithposition.svelte";
    import { onMount } from 'svelte';
    
    document.body.className = ""

    let components: typeof Notfoundwithposition[] = [];

  function copyComponent() {
    components = [...components, Notfoundwithposition];
  }

  // Optional: 이 예제에서는 초기에 하나의 컴포넌트를 배열에 추가합니다.
  onMount(() => {
    copyComponent();
  });
</script>

<main>
    <div>
        <img src="/background/sucks.jpg" alt="구린것들">
    </div>

    <div class="description">
        <h1>우리가 코딩에게 벽을 느끼는 이유.</h1>

        <p>
            스크래치는 작업을 쉽게 만들어주지만, <br />
            완성품도 쉽게 만들어버리는 문제가 있습니다.
        </p>
        

        <p>
            대한민국은 코딩 인프라가 잡히지 못해, <br />
            사실 코딩 교육이라는 틀 자체도 애매합니다.
        </p>

        <p>
            글로 연애를 배우면 어떻게 될까요? <br />
            코딩도 마찬가지 입니다.
        </p>

        <p>
            코딩도 코딩만의 언어가 있겠죠? <br />
            설명이 아주 배반적입니다.
        </p>

    </div>
</main>

<style>
    main {
        display: grid;
        grid-template-columns: 1fr 1fr;
        align-items: center;
        column-gap: 20%;

        width: 90%;
        margin: auto;

        height: 100%;
    }

    img {
        width: 100%;
        height: 100%;

        transform: translateX(35px);
    }

    p {
        font-size: x-large;
    }
</style>