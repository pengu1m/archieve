# sundayFC-CSS (v1.0.0)

A styleset of sundayFC frontend

## Getting started

First, you should install `dart sass`

```bash
npm install -g sass
```

You can compile `.scss` to `.css` with following command.

```bash
git clone https://github.com/pengu1m/sundayfc-css.git
sass main.scss ./build/min.css
# Compile main.scss
# It imports all files under 'components'
```

You can also use `--watch` or `--style=compressed` for dev and production.

## Style Concepts

- Refer the design of [Manchester City FC][mcity]
- Primary color: black and yellow

## Components

- Header
- Footer
- Jumbotron
- Grid
- Grid with ads
- Ads
- Card
- Button
- Responsive view
- Etc line
- Form
- Profile
- Pagination
- Match
- Table
- Bio
- Utility classes

Documents of components are [here][example]

[mcity]: https://www.mancity.com/
[example]: https://github.com/pengu1m/sundayfc-css/example
