const hamburger_btn = document.querySelector(".header__hamburger-btn")
const hamburger_back_btn = document.querySelector(".header__hamburger-back")
const hamburger_page = document.querySelector(".header__hamburger-page--hide")

if (hamburger_btn === null) throw new Error("Fail to get 'hamburger_btn' with a query '.header__hamburger-btn'")

if (hamburger_back_btn === null) throw new Error("Fail to get 'hamburger_back_btn' with a query '.header__hamburger-back'")

if (hamburger_page === null) throw new Error("Fail to get 'hamburger_page' with a query '.header__hamburger-page--hide'")

function open_page() {
    hamburger_page.classList.remove("header__hamburger-page--hide")
    hamburger_page.classList.add("header__hamburger-page--show")

    document.body.style.overflow = "hidden"
}

function close_page() {
    hamburger_page.classList.remove("header__hamburger-page--show")
    hamburger_page.classList.add("header__hamburger-page--hide")

    document.body.style.overflow = "scroll"
}

let page_opened = false;
hamburger_btn.addEventListener('click', () => {
    if (page_opened) {
        close_page();
    } else { // not opened
        open_page();
    }
})

hamburger_back_btn.addEventListener('click', close_page)
