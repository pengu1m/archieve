const tooltip_targets = document.querySelectorAll(".tooltip")

tooltip_targets.forEach(elem => {
    // get attribute
    let tooltip_text = elem.getAttribute("tooltip")
    if (tooltip_text == null) tooltip_text = "Fail to get attribute 'tooltip'"

    // make tooltip element
    const tooltip_element = document.createElement("div")
    tooltip_element.className = "tooltip-content--hide"
    tooltip_element.innerText = tooltip_text
    document.body.appendChild(tooltip_element)

    elem.addEventListener('mouseenter', () => {
        // set position
        const x = window.screenY + elem.getBoundingClientRect().top - 50;
        const y = window.screenX + elem.getBoundingClientRect().left;
        tooltip_element.style.top = `${x}px`;
        tooltip_element.style.left = `${y}px`;

        tooltip_element.className = "tooltip-content--show"
    })

    elem.addEventListener('mouseleave', () => {
        // set position
        const x = window.screenY + elem.getBoundingClientRect().top - 50;
        const y = window.screenX + elem.getBoundingClientRect().left;
        tooltip_element.style.top = `${x}px`;
        tooltip_element.style.left = `${y}px`;

        tooltip_element.className = "tooltip-content--hide"
    })
});
